# UPA_3
Autori: Ondrej Valo, Radoslav Páleník, Karel Fritz

VUT FIT - websites as data sources

e-shop used:
[BodyWorld](https://www.bodyworld.eu/cz/en/performance-c523)


## Spustenie
``` 
python3 get_urls.py [-h] [--base-url URL_LINK] [--product-url URL_LINK] [--save]
  -h, --help, show this help message and exit
  -b, --base-url, Base page of eshop
  -p, --product-url, page with products in eshop
  -s, --save, Save list of links as file
```

## Spustenie
``` 
python3 get_data.py [-h]
  -h, --help, show this help message and exit
  -rf, --read-file, read from file
  -s, --save, Save list of links as file
```